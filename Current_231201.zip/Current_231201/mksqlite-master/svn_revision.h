#ifndef __SVN_REVISION_H
#define __SVN_REVISION_H

#define SVNREV "build: Unversioned directory"

#endif // __SVN_REVISION_H